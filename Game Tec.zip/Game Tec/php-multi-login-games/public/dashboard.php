<?php
require_once __DIR__ . '/../config/connection.php';
require_login();
$user = current_user();
require __DIR__ . '/partials/header.php';
?>
<div class="p-4 bg-white rounded-3 shadow-sm">
  <h1 class="h4 mb-3">Dashboard</h1>
  <p>Bem-vindo, <strong><?= h($user['name']) ?></strong>! Seu perfil é <code><?= h($user['role']) ?></code>.</p>
  <hr>
  <?php if ($user['role'] === 'aluno'): ?>
    <h2 class="h6">Área do Aluno</h2>
    <p>Aqui você pode visualizar a lista de jogos e acessar os links.</p>
    <a class="btn btn-outline-primary btn-sm" href="games.php">Ir para Jogos</a>
  <?php elseif ($user['role'] === 'dev'): ?>
    <h2 class="h6">Área do Dev</h2>
    <p>Você pode cadastrar novos jogos (links) e gerenciá-los.</p>
    <a class="btn btn-outline-primary btn-sm" href="games.php">Gerenciar Jogos</a>
  <?php elseif ($user['role'] === 'escola'): ?>
    <h2 class="h6">Área da Escola</h2>
    <p>Você pode cadastrar jogos para sua turma e revisá-los.</p>
    <a class="btn btn-outline-primary btn-sm" href="games.php">Gerenciar Jogos</a>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
