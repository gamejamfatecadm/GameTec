<?php
require_once __DIR__ . '/../config/connection.php';

$q = trim($_GET['q'] ?? '');
if ($q) {
    $stmt = $pdo->prepare('
        SELECT g.*, u.name AS author
        FROM games g
        LEFT JOIN users u ON u.id = g.added_by
        WHERE g.title LIKE :q OR g.tags LIKE :q
        ORDER BY g.created_at DESC
    ');
    $stmt->execute([':q' => '%'.$q.'%']);
} else {
    $stmt = $pdo->query('
        SELECT g.*, u.name AS author
        FROM games g
        LEFT JOIN users u ON u.id = g.added_by
        ORDER BY g.created_at DESC
    ');
}
$games = $stmt->fetchAll();

require __DIR__ . '/partials/header.php';
?>
<div class="row g-4">
  <div class="col-12 col-lg-8">
    <div class="p-4 bg-white rounded-3 shadow-sm">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h5 mb-0">Jogos</h1>
        <form class="d-flex" method="get" action="">
          <input class="form-control form-control-sm me-2" type="search" name="q" value="<?= h($q) ?>" placeholder="Buscar por título ou tag">
          <button class="btn btn-outline-secondary btn-sm">Buscar</button>
        </form>
      </div>

      <?php if (isset($_GET['ok'])): ?>
        <div class="alert alert-success py-2">Operação realizada com sucesso.</div>
      <?php elseif (isset($_GET['err'])): ?>
        <div class="alert alert-danger py-2">Algo deu errado. Verifique os campos.</div>
      <?php endif; ?>

      <?php if (!$games): ?>
        <p class="text-muted">Nenhum jogo cadastrado ainda.</p>
      <?php else: ?>
        <div class="list-group">
          <?php foreach ($games as $g): ?>
            <div class="list-group-item">
              <div class="d-flex w-100 justify-content-between">
                <h2 class="h6 mb-1">
                  <a href="<?= h($g['url']) ?>" target="_blank" rel="noopener"><?= h($g['title']) ?></a>
                </h2>
                <small class="text-muted"><?= date('d/m/Y H:i', strtotime($g['created_at'])) ?></small>
              </div>
              <p class="mb-1 small"><?= h($g['platform'] ?: 'Web') ?></p>
              <div class="small text-muted">
                <?php if (!empty($g['tags'])): ?>Tags: <?= h($g['tags']) ?><?php endif; ?>
                <?php if (!empty($g['author'])): ?><span class="ms-2">• por <?= h($g['author']) ?></span><?php endif; ?>
              </div>

              <?php if (is_logged_in() && in_array(current_user()['role'], ['dev','escola'], true)): ?>
                <div class="mt-2 d-flex gap-2">
                  <a class="btn btn-sm btn-outline-primary" href="game_form.php?id=<?= (int)$g['id'] ?>">Editar</a>
                  <form method="post" action="game_delete.php" onsubmit="return confirm('Excluir este jogo?');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= (int)$g['id'] ?>">
                    <button class="btn btn-sm btn-outline-danger" type="submit">Excluir</button>
                  </form>
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-12 col-lg-4">
    <div class="p-4 bg-white rounded-3 shadow-sm">
      <h2 class="h6">Cadastrar jogo</h2>
      <?php if (!is_logged_in()): ?>
        <p class="text-muted">Faça <a href="login.php">login</a> como <strong>dev</strong> ou <strong>escola</strong> para cadastrar.</p>
      <?php elseif (!in_array(current_user()['role'], ['dev','escola'], true)): ?>
        <p class="text-muted">Apenas perfis <strong>dev</strong> ou <strong>escola</strong> podem cadastrar jogos.</p>
      <?php else: ?>
        <form method="post" action="game_form.php">
          <?= csrf_field() ?>
          <div class="mb-2">
            <label class="form-label">Título</label>
            <input class="form-control" name="title" required>
          </div>
          <div class="mb-2">
            <label class="form-label">URL</label>
            <input class="form-control" name="url" type="url" placeholder="https://..." required>
          </div>
          <div class="mb-2">
            <label class="form-label">Plataforma</label>
            <input class="form-control" name="platform" placeholder="Web, Roblox, Itch.io, etc.">
          </div>
          <div class="mb-3">
            <label class="form-label">Tags</label>
            <input class="form-control" name="tags" placeholder="ação;educativo;2D">
          </div>
          <button class="btn btn-primary w-100" type="submit">Salvar</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
