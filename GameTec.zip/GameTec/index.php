<!DOCTYPE html>
<html lang="en""pt-br">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- 
    - primary meta tags
  -->
  <title>GameJam - De alunos para alunos! </title>
  <meta name="title" content=" GameJam - De alunos para alunos! ">
  <meta name="description" content="This is an esports and gaming html template made by codewithsadee">

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Oxanium:wght@400;500;600;700&family=Work+Sans:wght@600&display=swap"
    rel="stylesheet">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-banner.png">
  <link rel="preload" as="image" href="./assets/images/hero-banner-bg.png">

</head>

<body id="top">

  <!-- 
    - #HEADER
  -->

  <header class="header active" data-header>
    <div class="container">

      <a href="#" class="logo">
        <img src="./assets/images/logo.svg" width="110" height="53" alt="GameTec home">
      </a>

      <nav class="navbar" data-navbar>
        <ul class="navbar-list">

          <li class="navbar-item">
            <a href="#home" class="navbar-link" data-nav-link>Home</a>
          </li>

          <li class="navbar-item">
            <a href="#premiados" class="navbar-link" data-nav-link>Premiados</a>
          </li>

          <li class="navbar-item">
            <a href="#jogos" class="navbar-link" data-nav-link>Jogos</a>
          </li>

          <li class="navbar-item">
            <a href="#footer-list" class="navbar-link" data-nav-link>Contato</a>
          </li>

        </ul>
      </nav>

      <a href="#" class="btn" data-btn>SAIBA MAIS SOBRE O GAMEJAM</a>

      <button class="nav-toggle-btn" aria-label="toggle menu" data-nav-toggler>
        <span class="line line-1"></span>
        <span class="line line-2"></span>
        <span class="line line-3"></span>
      </button>

    </div>
  </header>





  <main>
    <article>

      <!-- 
        - #HERO
      -->

      <div class="hero has-before" id="home">
        <div class="container">

          <p class="section-subtitle">De alunos para alunos</p>

          <h1 class="h1 title hero-title"> GameTec<br></h1>

          <a href="#" class="btn" data-btn>JOGUE AGORA!</a>

          <div class="hero-banner">
            <img src="./assets/images/hero-banner.png" width="850" height="414" alt="hero banner" class="w-100">

            <img src="./assets/images/hero-banner-bg.png" alt="" class="hero-banner-bg">
          </div>

        </div>
      </div>


<!--- #PREMIADOS -->
     
<section class="section upcoming relative z-0" aria-labelledby="upcoming-label" id="premiados">
  <div class="container text-center">

    <h2 class="h2 section-title mb-8" data-reveal="bottom">
      Jogos <span class="span">premiados</span>
    </h2>

    <p class="section-text mb-12" data-reveal="bottom">
      Confira os jogos vencedores da última edição do GameJam - Fatec
    </p>

    <!-- Carrossel -->
    <div class="w-full max-w-6xl mx-auto px-6 overflow-x-auto scrollbar-hide">
      <div class="flex flex-nowrap justify-center items-end py-6">

        <!-- Card 1 -->
        <div class="card min-w-[275px] h-[350px] rounded-xl flex flex-col items-center justify-center text-xl font-bold text-white animate-bg-gradient">
          <img src="./assets/images/team-logo-1.png" alt="Matemágico" class="w-24 h-24 mb-4">
          <h3 class="h3">Matemágico</h3>
          <p class="card-meta mt-2 text-gray-200 text-sm">Group 04 | 25 Maio 2024</p>
        </div>

        <!-- Card 2 -->
        <div class="card min-w-[275px] h-[350px] rounded-xl flex flex-col items-center justify-center text-xl font-bold text-white animate-bg-gradient">
          <img src="./assets/images/team-logo-2.png" alt="Trigger Brain Squad" class="w-24 h-24 mb-4">
          <h3 class="h3">Trigger Brain Squad</h3>
          <p class="card-meta mt-2 text-gray-200 text-sm">Group 05 | 10 Jan 2024</p>
        </div>

        <!-- Card 3 -->
        <div class="card min-w-[275px] h-[350px] rounded-xl flex flex-col items-center justify-center text-xl font-bold text-white animate-bg-gradient">
          <img src="./assets/images/team-logo-3.png" alt="Witches And Quizards" class="w-24 h-24 mb-4">
          <h3 class="h3">Witches And Quizards</h3>
          <p class="card-meta mt-2 text-gray-200 text-sm">Group 02 | 15 Dez 2024</p>
        </div>

      </div>
    </div>
  </div>
</section>


</section>

<style>
 /* Gradiente animado igual ao botão */
.animate-bg-gradient {
  background: linear-gradient(hsl(299, 100%, 52%), hsl(291, 100%, 58%), hsl(283, 100%, 60%), hsl(273, 100%, 62%), hsl(262, 100%, 63%), hsl(242, 100%, 69%), hsl(223, 100%, 62%), hsl(210, 100%, 50%), hsl(203, 100%, 50%), hsl(198, 100%, 50%), hsl(192, 100%, 48%), hsl(185, 90%, 48%));
  background-size: 200% 200%;
  transition: transform 0.5s ease, box-shadow 0.5s ease;
  box-shadow: 0 8px 20px rgba(0,0,0,0.35);
  border-radius: 1rem;
}

.animate-bg-gradient:hover {
  animation: gradientAnimation 6s ease infinite;
  transform: scale(1.05);
  box-shadow: 0 12px 30px rgba(0,0,0,0.5);
  z-index: 6;
}

@keyframes gradientAnimation {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

/* Mobile: coluna centralizada */
@media (max-width: 767px) {
  .flex.flex-nowrap {
    flex-direction: column !important;
    align-items: center !important;
  }
  .card {
    min-width: 90% !important;
    max-width: 300px;
    margin-bottom: 1.5rem !important;
  }
}

/* Esconde scrollbar */
.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }


</style>


      <!-- 
        - #JOGOS
      -->

      <section class="section jogos" aria-label="our latest jogos" id="jogos">
        <div class="container">

          <p class="section-subtitle" data-reveal="bottom"></p>

          <h2 class="h2 section-title" data-reveal="bottom">
            jogos <span class="span"></span>
          </h2>

          <p class="section-text" data-reveal="bottom">
           Confira todos os jogos desenvolvidos no GameJam!
          </p>

          <ul class="jogos-list">

            <li data-reveal="bottom">
              <div class="jogos-card">

                <figure class="card-banner img-holder" style="--width: 600; --height: 400;">
                  <img src="./assets/images/news-1.jpg" width="600" height="400" loading="lazy"
                    alt="Innovative Business All Over The World." class="img-cover">
                </figure>

                <div class="card-content">

                  <a href="#" class="card-tag">Jogar</a>

                  <ul class="card-meta-list">

                    <li class="card-meta-item">
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      

                  </ul>

                  <h3 class="h3">
                    <a href="#" class="card-title">MYTHS OF DIANA</a>
                  </h3>

                  <p class="card-text">
                    Financial experts support or help you to to find out which way you can raise your funds more...
                  </p>

                  <a href="#" class="link has-before">Read More</a>

                </div>

              </div>
            </li>

            <li data-reveal="bottom">
              <div class="jogos-card">

                <figure class="card-banner img-holder" style="--width: 600; --height: 400;">
                  <img src="./assets/images/news-2.jpg" width="600" height="400" loading="lazy"
                    alt="How To Start Initiating An Startup In Few Days." class="img-cover">
                </figure>

                <div class="card-content">

                  <a href="#" class="card-tag">Jogar</a>

                  <ul class="card-meta-list">

                    <li class="card-meta-item">
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      
                  </ul>

                  <h3 class="h3">
                    <a href="#" class="card-title">COUNT'S KINGDOM</a>
                  </h3>

                  <p class="card-text">
                    Financial experts support or help you to to find out which way you can raise your funds more...
                  </p>

                  <a href="#" class="link has-before">Read More</a>

                </div>

              </div>
            </li>

            <li data-reveal="bottom">
              <div class="jogos-card">

                <figure class="card-banner img-holder" style="--width: 600; --height: 400;">
                  <img src="./assets/images/news-3.jpg" width="600" height="400" loading="lazy"
                    alt="Financial Experts Support Help You To Find Out." class="img-cover">
                </figure>

                <div class="card-content">

                  <a href="#" class="card-tag">Jogar</a>

                  <ul class="card-meta-list">

                    <li class="card-meta-item">
                       <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      <ion-icon name="star" aria-hidden="true"></ion-icon>
                      

                  </ul>

                  <h3 class="h3">
                    <a href="#" class="card-title">MATH QUEST</a>
                  </h3>

                  <p class="card-text">
                    Financial experts support or help you to to find out which way you can raise your funds more...
                  </p>

                  <a href="#" class="link has-before">Read More</a>

                </div>

              </div>
            </li>

          </ul>

        </div>
      </section>

    </article>
  </main>





  <!-- 
    - #FOOTER
  -->

  <footer class="footer">

    <div class="section footer-top">
      <div class="container">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="./assets/images/logo.svg" width="150" height="73" loading="lazy" alt="GameTec logo">
          </a>

          <p class="footer-text">
         De alunos para alunos
          </p>

          <ul class="social-list">

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-youtube"></ion-icon>
              </a>
            </li>

          </ul>

        </div>

         <div class="footer-list" id="footer-list">

          <p class="title footer-list-title has-after">Links Úteis</p>

          <ul>

            <li>
              <a href="#premiados" class="footer-link">Premiados</a>
            </li>

            <li>
              <a href="#" class="footer-link">Ajuda</a>
            </li>

            <li>
              <a href="#" class="footer-link">Política de Privacidade</a>
            </li>

            <li>
              <a href="#" class="footer-link">Termos de Uso</a>
            </li>

            <li>
              <a href="#" class="footer-link"></a>
            </li>

          </ul>

        </div>

        <div class="footer-list">

          <p class="title footer-list-title has-after">Informações de Contato</p>

          <div class="contact-item">
            <span class="span">Endereço:</span>

            <address class="contact-link">
              R.Ítalo Nascimento, 366 - Praia do Porto Grande, São Sebastião - SP, 11608-248
            </address>
          </div>

          <div class="contact-item">
            <span class="span">E-mail:</span>

            <a href="mailto:gamejamfatec.adm@gmail.com" class="contact-link">gamejamfatec.adm@gmail.com</a>
          </div>

          <div class="contact-item">
            <span class="span">Telefone:</span>

            <a href="tel:+12345678910" class="contact-link">+55 12 99788-3141</a>
          </div>

        </div>

        <div class="footer-list"> 

          <p class="title footer-list-title has-after">Fale Conosco</p>

          <form action="./index.html" method="get" class="footer-form">
            <input type="email" name="email_address" required placeholder="E-mail" autocomplete="off"
              class="input-field">

            <button type="submit" class="btn" data-btn>Inscreva-se</button>
          </form>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          &copy; 2022 codewithsadee All Rights Reserved.
        </p>

      </div>
    </div>

  </footer>





  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-top-btn" aria-label="back to top" data-back-top-btn>
    <ion-icon name="arrow-up-outline" aria-hidden="true"></ion-icon>
  </a>





  <!-- 
    - #CUSTOM CURSOR
  -->

  <div class="cursor" data-cursor></div>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js"></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>