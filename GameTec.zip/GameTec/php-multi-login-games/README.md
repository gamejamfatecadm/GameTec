# PHP Multi-Role Login + Games Links

Projeto exemplo em PHP (PDO + MySQL) com **3 tipos de login** (`aluno`, `dev`, `escola`) e um módulo simples de **jogos** (links).

## Requisitos
- PHP 8+ com extensões: `pdo`, `pdo_mysql`, `mbstring`, `openssl`
- MySQL/MariaDB
- Servidor local (XAMPP, WAMP, Laragon etc.)

## Instalação
1. Crie um banco de dados no MySQL (ex.: `multilogin_games`).
2. Edite `config/config.php` com suas credenciais do MySQL.
3. Importe o arquivo `database/migrate.sql` no seu banco.
4. Coloque esta pasta dentro de `htdocs` (XAMPP) ou configure o VirtualHost apontando para `public/`.
5. Acesse `http://localhost/` (ou o host definido).

## Logins de teste (após rodar o SQL de migração)
- aluno: `aluno@teste.com` / senha: `123456`
- dev: `dev@teste.com` / senha: `123456`
- escola: `escola@teste.com` / senha: `123456`

## Estrutura
```
public/
  index.php        # Landing com seleção de perfil
  login.php        # Login (seleciona role)
  logout.php
  dashboard.php    # Dashboard com conteúdo por role
  games.php        # Lista + cadastro (dev/escola)
  partials/
    header.php
    footer.php
config/
  config.php       # Credenciais e opções
  connection.php   # PDO, sessão e helpers
database/
  migrate.sql      # Schema + inserts
```

## Segurança (resumo)
- `password_hash` / `password_verify` para senhas
- Prepared statements em todas as queries
- Verificação de role em rotas sensíveis
- Filtro/escape básico de saída (`htmlspecialchars`)

## Observações
Este é um **modelo base** para você expandir no VSCode. A partir dele, você pode:
- adicionar cadastro de usuários real,
- implementar edição/remoção de jogos,
- criar painéis separados por role,
- usar Bootstrap/ Tailwind para estilizar.
