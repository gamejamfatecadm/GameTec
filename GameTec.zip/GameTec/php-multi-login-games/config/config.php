<?php
// config/config.php
// Ajuste para o seu ambiente local

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'multilogin_games');
define('DB_USER', 'root');
define('DB_PASS', '');

// Opções gerais
define('APP_NAME', 'MultiLogin + Games');
define('APP_BASEURL', '/php-multi-login-games/public/');

