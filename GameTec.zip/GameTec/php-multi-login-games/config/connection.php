<?php
// config/connection.php
require_once __DIR__ . '/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

try {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die('Erro ao conectar no banco: ' . htmlspecialchars($e->getMessage()));
}

function is_logged_in(): bool { return isset($_SESSION['user']); }
function current_user() { return $_SESSION['user'] ?? null; }
function require_login() {
    if (!is_logged_in()) { header('Location: ' . APP_BASEURL . 'login.php'); exit; }
}
/** @param array|string $roles */
function require_role($roles) {
    require_login();
    $user = current_user();
    $roles = is_array($roles) ? $roles : [$roles];
    if (!$user || !in_array($user['role'], $roles, true)) {
        http_response_code(403);
        echo '<h1 style="font-family:sans-serif">Acesso negado</h1><p><a href="dashboard.php">Voltar</a></p>';
        exit;
    }
}
function h($str){ return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8'); }

/* --- CSRF --- */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="'.h(csrf_token()).'">';
}
function verify_csrf() {
    $ok = isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']);
    if (!$ok) { http_response_code(400); exit('Falha de verificação CSRF.'); }
}
