-- database/migrate.sql
DROP TABLE IF EXISTS games;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('aluno','dev','escola') NOT NULL DEFAULT 'aluno',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE games (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(160) NOT NULL,
  url VARCHAR(500) NOT NULL,
  platform VARCHAR(60) DEFAULT 'Web',
  tags VARCHAR(255) NULL,
  added_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_games_user FOREIGN KEY (added_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Usuários de exemplo (senha 123456)
INSERT INTO users (name, email, password_hash, role) VALUES
('Aluno Teste', 'aluno@teste.com',  '$2y$10$o3a8xK1tYyW0GqfZ3I1qT.CM21v7V3xWyHRSJb88vVQ5b3Z4z3kOq', 'aluno'),
('Dev Teste',   'dev@teste.com',    '$2y$10$o3a8xK1tYyW0GqfZ3I1qT.CM21v7V3xWyHRSJb88vVQ5b3Z4z3kOq', 'dev'),
('Escola Teste','escola@teste.com', '$2y$10$o3a8xK1tYyW0GqfZ3I1qT.CM21v7V3xWyHRSJb88vVQ5b3Z4z3kOq', 'escola');

-- Jogo exemplo
INSERT INTO games (title, url, platform, tags, added_by) VALUES
('T-Rex Runner', 'https://chromedino.com/', 'Web', 'retro;offline;jump', 2);
