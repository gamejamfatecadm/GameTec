<?php
require_once __DIR__ . '/../config/connection.php';

// configure aqui o usuário e a nova senha:
$email = "aluno@teste.com";
$novaSenha = "1234";

// gera um hash novo
$hash = password_hash($novaSenha, PASSWORD_BCRYPT);

// atualiza no banco
$stmt = $pdo->prepare("UPDATE users SET password_hash = :h WHERE email = :e");
$stmt->execute([':h' => $hash, ':e' => $email]);

echo "Senha de {$email} redefinida para '{$novaSenha}'.<br>";
echo "Hash novo salvo: {$hash}";
