<?php
require_once __DIR__ . '/../config/connection.php';
require_role(['dev','escola']);
verify_csrf();

$id = (int)($_POST['id'] ?? 0);
if ($id > 0) {
    $stmt = $pdo->prepare('DELETE FROM games WHERE id = :id');
    $stmt->execute([':id'=>$id]);
    header('Location: games.php?ok=1'); exit;
}
header('Location: games.php?err=1');
