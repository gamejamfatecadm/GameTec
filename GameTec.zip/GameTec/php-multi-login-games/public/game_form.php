<?php
require_once __DIR__ . '/../config/connection.php';
require_role(['dev','escola']);

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($method === 'GET') {
    $game = ['title'=>'','url'=>'','platform'=>'','tags'=>''];
    if ($id > 0) {
        $stmt = $pdo->prepare('SELECT * FROM games WHERE id = :id');
        $stmt->execute([':id'=>$id]);
        $game = $stmt->fetch();
        if (!$game) { header('Location: games.php?err=1'); exit; }
    }
    require __DIR__ . '/partials/header.php';
    ?>
    <div class="p-4 bg-white rounded-3 shadow-sm">
      <h1 class="h5 mb-3"><?= $id ? 'Editar jogo' : 'Novo jogo' ?></h1>
      <form method="post" action="">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int)$id ?>">
        <div class="mb-2">
          <label class="form-label">Título</label>
          <input class="form-control" name="title" value="<?= h($game['title']) ?>" required>
        </div>
        <div class="mb-2">
          <label class="form-label">URL</label>
          <input class="form-control" name="url" type="url" value="<?= h($game['url']) ?>" required>
        </div>
        <div class="mb-2">
          <label class="form-label">Plataforma</label>
          <input class="form-control" name="platform" value="<?= h($game['platform']) ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Tags</label>
          <input class="form-control" name="tags" value="<?= h($game['tags']) ?>">
        </div>
        <div class="d-flex gap-2">
          <button class="btn btn-primary" type="submit">Salvar</button>
          <a class="btn btn-outline-secondary" href="games.php">Cancelar</a>
        </div>
      </form>
    </div>
    <?php
    require __DIR__ . '/partials/footer.php';
    exit;
}

/* POST: criar/atualizar */
verify_csrf();

$title = trim($_POST['title'] ?? '');
$url = trim($_POST['url'] ?? '');
$platform = trim($_POST['platform'] ?? '');
$tags = trim($_POST['tags'] ?? '');
$id = (int)($_POST['id'] ?? 0);

if (!$title || !filter_var($url, FILTER_VALIDATE_URL)) {
    header('Location: games.php?err=1'); exit;
}

if ($id > 0) {
    $stmt = $pdo->prepare('UPDATE games SET title=:title, url=:url, platform=:platform, tags=:tags WHERE id=:id');
    $stmt->execute([
        ':title'=>$title, ':url'=>$url, ':platform'=>$platform, ':tags'=>$tags, ':id'=>$id
    ]);
} else {
    $stmt = $pdo->prepare('INSERT INTO games (title, url, platform, tags, added_by) VALUES (:t,:u,:p,:g,:by)');
    $stmt->execute([
        ':t'=>$title, ':u'=>$url, ':p'=>$platform, ':g'=>$tags, ':by'=>current_user()['id']
    ]);
}

header('Location: games.php?ok=1');
