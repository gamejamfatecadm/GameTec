<?php require __DIR__ . '/partials/header.php'; ?>
<div class="row g-4">
  <div class="col-12 col-lg-8">
    <div class="p-4 bg-white rounded-3 shadow-sm">
      <h1 class="h4 mb-3">Bem-vindo!</h1>
      <p>Este é um modelo base com **3 perfis**: <code>aluno</code>, <code>dev</code> e <code>escola</code>.</p>
      <p>Faça login para acessar o dashboard e ver conteúdos específicos por perfil.</p>
      <a class="btn btn-primary" href="login.php">Ir para o Login</a>
      <a class="btn btn-outline-secondary" href="games.php">Ver Jogos</a>
    </div>
  </div>
  <div class="col-12 col-lg-4">
    <div class="p-4 bg-white rounded-3 shadow-sm">
      <h2 class="h6">Dicas</h2>
      <ul class="mb-0">
        <li>As senhas são armazenadas com <code>password_hash</code>.</li>
        <li>As rotas verificam sessão e role.</li>
        <li>Os jogos são, por enquanto, apenas links.</li>
      </ul>
    </div>
  </div>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
