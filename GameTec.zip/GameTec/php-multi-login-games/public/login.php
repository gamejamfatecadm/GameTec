<?php
// public/login.php (senha em texto puro)
declare(strict_types=1);
require_once __DIR__ . '/../config/connection.php';

if (is_logged_in()) {
    header('Location: ' . APP_BASEURL . 'dashboard.php');
    exit;
}

$error  = '';
$role   = $_GET['role'] ?? 'aluno';
$emailV = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role   = trim($_POST['role'] ?? 'aluno');
    $email  = trim($_POST['email'] ?? '');
    $passwd = (string)($_POST['password'] ?? '');
    $emailV = $email;

    if ($email === '' || $passwd === '') {
        $error = 'Preencha e-mail e senha.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'E-mail inválido.';
    } elseif (!in_array($role, ['aluno','dev','escola'], true)) {
        $error = 'Perfil inválido.';
    } else {
        // Busca por e-mail e depois valida role + senha EM TEXTO PURO
        $stmt = $pdo->prepare('SELECT id, name, email, password_hash, role FROM users WHERE email = :email LIMIT 1');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user) {
            $error = 'Usuário não encontrado para o e-mail informado.';
        } elseif ($user['role'] !== $role) {
            $error = 'O perfil selecionado não corresponde ao seu usuário.';
        } elseif ($passwd !== (string)$user['password_hash']) {
            // comparação direta, sem password_verify
            $error = 'Senha incorreta.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id'    => (int)$user['id'],
                'name'  => $user['name'],
                'email' => $user['email'],
                'role'  => $user['role'],
            ];
            header('Location: ' . APP_BASEURL . 'dashboard.php');
            exit;
        }
    }
}

require __DIR__ . '/partials/header.php';
?>
<div class="row justify-content-center">
  <div class="col-12 col-sm-10 col-md-8 col-lg-6">
    <div class="p-4 bg-white rounded-3 shadow-sm">
      <h1 class="h4 mb-3">Login</h1>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
      <?php endif; ?>

      <form method="post" action="">
        <div class="mb-3">
          <label class="form-label">Perfil</label>
          <select class="form-select" name="role" required>
            <option value="aluno"  <?= $role==='aluno'?'selected':''  ?>>Aluno</option>
            <option value="dev"    <?= $role==='dev'?'selected':''    ?>>Dev</option>
            <option value="escola" <?= $role==='escola'?'selected':'' ?>>Escola</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">E-mail</label>
          <input type="email" class="form-control" name="email" value="<?= h($emailV) ?>"
                 placeholder="voce@exemplo.com" autocomplete="username" required>
        </div>

        <div class="mb-3">
          <label class="form-label d-flex justify-content-between">
            <span>Senha</span>
            <button type="button" class="btn btn-link p-0 small" id="togglePass">mostrar/ocultar</button>
          </label>
          <input type="password" class="form-control" name="password" id="password"
                 autocomplete="current-password" required>
        </div>

        <div class="d-flex gap-2">
          <button class="btn btn-primary" type="submit">Entrar</button>
          <a class="btn btn-outline-secondary" href="<?= h(APP_BASEURL) ?>index.php">Cancelar</a>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  document.getElementById('togglePass').addEventListener('click', function () {
    const i = document.getElementById('password');
    i.type = i.type === 'password' ? 'text' : 'password';
  });
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
