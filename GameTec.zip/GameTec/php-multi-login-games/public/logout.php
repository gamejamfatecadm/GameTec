<?php
require_once __DIR__ . '/../config/connection.php';
session_destroy();
header('Location: index.php');
exit;
